import React, { useRef, useState } from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';
import MapView from 'react-native-maps';

const styles = StyleSheet.create({
    container: {
        ...StyleSheet.absoluteFillObject,
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center'
    },
    map: {
        ...StyleSheet.absoluteFillObject
    },
    text: {
        fontSize: 20,
        backgroundColor: 'lightblue'
    }
})

const DEFAULT_HYD_LAT = 17.3850;
const DEFAULT_HYD_LON = 78.4867;
const INITIAL_REGION = {
    latitude: DEFAULT_HYD_LAT,
    longitude: DEFAULT_HYD_LON,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01
};

const HomeCompoent = () => {
    const mapRef = useRef(null);
    const [region, setRegion] = useState(INITIAL_REGION);
    const goToBangalore = () => {
        const bangaloreRegion = {
            latitude: 12.9716,
            longitude: 77.5946,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01
        };

        mapRef.current.animateToRegion(bangaloreRegion, 3 * 1000);
    };

    return (
        <View style={styles.container}>
            <MapView style={styles.map} ref={mapRef}
                initialRegion={INITIAL_REGION}
                onRegionChangeComplete={region => setRegion(region)} />
            <Button title="Go to Bangalore" onPress={() => goToBangalore()} />
            <Text style={styles.text}>Current Latitude: {region.latitude}</Text>
            <Text style={styles.text}>Current Longitude: {region.longitude}</Text>
        </View>
    )
};

export {
    HomeCompoent
};