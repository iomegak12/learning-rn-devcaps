import { HomeCompoent } from './HomeComponent';

export default function App() {
  return (
    <HomeCompoent />
  );
}

