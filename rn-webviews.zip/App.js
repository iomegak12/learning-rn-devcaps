import { WebComponent } from "./WebComponent";

export default function App() {
  return (
    <WebComponent />
  );
}
