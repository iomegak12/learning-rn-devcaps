import React, { useRef } from 'react';
import { StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f6f6f6',
        alignItems: 'center',
        justifyContent: 'center',
    },
});


const WebComponent = () => {
    let counter = 1;

    const runFirstScript = `
        setTimeout(function() {
            window.alert("Click Me!");

            document.getElementById("h2_element").innerHTML = "This value is changed ...";		
        }, 1000);`;

    const script = (language) => {
        return `
            setTimeout(function() {
                window.alert("Click Me!");

                document.getElementById("h2_element").innerHTML = "${language}";		
            }, 1000);
            
            document.getElementById("btnClick").onclick = () => {
                window.ReactNativeWebView.postMessage("hello");
            };
            `;
    };

    const customHTML = `
        <body style="display:flex; flex-direction: column;justify-content: center; 
            align-items:center; background-color: black; color:white; height: 100%;">
            <h1 style="font-size:100px; padding: 50px; text-align: center;" 
            id="h1_element">
            This is simple html
            </h1>
            <h2 style="display: block; font-size:80px; padding: 50px; 
            text-align: center;" id="h2_element">
            This text will be changed later!
            </h2>

            <button id="btnClick">Click Here</input>
        </body>`;

    const webRef = useRef(null);
    const favoriteProgrammingLanguages = [
        "C++",
        "Rust",
        "Javascript",
        "Python",
        "C#",
        "M",
        "Haskell"
    ];

    const selectProgrammingLanguage = () => {
        const randomInt = Math.floor(
            Math.random() * (favoriteProgrammingLanguages.length));

        return favoriteProgrammingLanguages[randomInt];
    };

    const handleLoadEnd = () => {
        setTimeout(() => {
            webRef.current.injectJavaScript(script(selectProgrammingLanguage()));
        }, 5000);
    };

    return (
        <WebView source={{ html: customHTML }}
            ref={webRef}
            originWhitelist={['*']}
            injectedJavaScript={runFirstScript}
            onLoadEnd={handleLoadEnd}
            onMessage={(event) => alert(`Event from Webview to React Native ${event.nativeEvent.data}`)}
            style={{ height: "100%", width: "100%", overflow: 'hidden' }} />
    );
};

export {
    WebComponent
};