import { HomeComponentV2 } from './HomeComponentv2';

export default function App() {
  return (
    <HomeComponentV2 />
  );
};