import React, { useState } from 'react';
import { StyleSheet, SafeAreaView, View, TextInput, Text, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10,
        backgroundColor: 'white',
    },
    titleText: {
        fontSize: 22,
        fontWeight: 'bold',
        textAlign: 'center',
        paddingVertical: 20,
    },
    textStyle: {
        padding: 10,
        textAlign: 'center',
    },
    buttonStyle: {
        fontSize: 16,
        color: 'white',
        backgroundColor: 'green',
        padding: 5,
        marginTop: 32,
        minWidth: 250,
    },
    buttonTextStyle: {
        padding: 5,
        color: 'white',
        textAlign: 'center',
    },
    textInputStyle: {
        textAlign: 'center',
        height: 40,
        width: '100%',
        borderWidth: 1,
        borderColor: 'green',
    },
});

const INPUT_KEY = "@InputKey";

const HomeCompoent = () => {
    const [textInputValue, setTextInputValue] = useState('');
    const saveValue = () => {
        if (textInputValue) {
            AsyncStorage.setItem(INPUT_KEY, textInputValue);
            setTextInputValue("");

            alert("Data Saved Successfully!");
        } else {
            alert("Please fill data in the Input value!");
        }
    };

    const getValue = () => {
        AsyncStorage
            .getItem(INPUT_KEY)
            .then(value => {
                setTextInputValue(value);
            });
    };

    return (
        <>
            <SafeAreaView style={{ flex: 1 }}>
                <View style={styles.container}>
                    <Text style={styles.titleText}>
                        AsyncStorage in React Native
                    </Text>
                    <TextInput
                        placeholder="Enter Some Text here"
                        underlineColorAndroid="transparent"
                        style={styles.textInputStyle}
                        value={textInputValue}
                        onChangeText={(text) => setTextInputValue(text)}
                    />
                    <TouchableOpacity
                        style={styles.buttonStyle}
                        onPress={saveValue}>
                        <Text style={styles.buttonTextStyle}> SAVE VALUE </Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.buttonStyle}
                        onPress={getValue}>
                        <Text style={styles.buttonTextStyle}> GET VALUE </Text>
                    </TouchableOpacity>
                    <Text style={styles.textStyle}> {textInputValue} </Text>
                </View>
            </SafeAreaView>
        </>
    )
};

export {
    HomeCompoent
};